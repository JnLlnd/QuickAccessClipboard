# Ahk2Exe #

Ahk2Exe is the official AutoHotkey script to EXE converter, which is written itself in AutoHotkey.

http://www.ahkscript.org/


## How to Compile ##

Ahk2Exe can compile itself, just be sure to use a recent AutoHotkey self-contained binary.


## To do ##

  - Handle FileInstall on same-line If* commands.

